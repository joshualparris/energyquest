using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VehicleController : MonoBehaviour
{
    public float speed = 10f; // The speed at which the vehicle moves
    public float rotationSpeed = 100f; // The speed at which the vehicle rotates
    public float distance = 5.0f; // The distance between the camera and the vehicle
    public float height = 5.0f; // The height offset of the camera

    // Update is called once per frame
    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal"); // Get input from left/right arrow keys
        float verticalInput = Input.GetAxis("Vertical"); // Get input from up/down arrow keys

        // Move the vehicle forward/backward based on vertical input
        transform.Translate(Vector3.forward * speed * verticalInput * Time.deltaTime);

        // Rotate the vehicle left/right based on horizontal input
        transform.Rotate(Vector3.up * rotationSpeed * horizontalInput * Time.deltaTime);
    }
}
