using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowTarget : MonoBehaviour
{
    public Transform target; // The target that the camera will follow
    public float distance = 5.0f; // The distance between the camera and the target
    public float height = 5.0f; // The height offset of the camera

    // Update is called once per frame
    void LateUpdate()
    {
        // Move the camera to follow the target with a distance and height offset
        transform.position = target.position - target.forward * distance + Vector3.up * height;
        transform.LookAt(target); // Make the camera look at the target
    }
}
